# AWS Cognito Terraform Module 

## Overview

## What is Amazon Cognito?

Amazon Cognito is an identity platform for web and mobile apps. It’s a user directory, an authentication server, and an authorization service for OAuth 2.0 access tokens and AWS credentials. With Amazon Cognito, you can authenticate and authorize users from the built-in user directory, from your enterprise directory, and from consumer identity providers like Google and Facebook.

# terraform-aws-cognito-user-pool

A [Terraform] module for deploying and managing
[Cognito User Pools]
on [Amazon Web Services (AWS)][AWS].

*This module supports Terraform v1.x, v0.15, v0.14, v0.13 as well as v0.12.20 and above
and is compatible with the Terraform AWS provider v3.50 and above.

## Module Features

In contrast to the plain [`cognito_user_pool`](https://www.terraform.io/docs/providers/aws/r/cognito_user_pool.html)
resource this module has a more secure level of default settings.

# User pools

>![Architecture diagram](documentation/User_pools.png)

Create a user pool when you want to authenticate and authorize users to your app or API. User pools are a user directory with both self-service and administrator-driven user creation, management, and authentication. Your user pool can be an independent directory and OIDC identity provider (IdP), and an intermediate service provider (SP) to third-party providers of workforce and customer identities. Your organization's SAML 2.0 and OIDC IdPs bring workforce identities into Cognito and your app. The public OAuth 2.0 identity stores Amazon, Google, Apple and Facebook bring customer identities.

User pools don’t require integration with an identity pool. From a user pool, you can issue authenticated JSON web tokens (JWTs) directly to an app, a web server, or an API.

### Important note for creating the Lambda function for use with the User Pool"

To deploy the Lambda function "pre sign up" and also the "custom message" it was necessary to create the resource in the terraform "resource "aws_lambda_permission".

Furthermore, it was necessary to create a test lambda function with the Ruby code below:

require 'json'

def lambda_handler(event:, context:)
    # TODO implement
    return event
end

# terraform-aws-cognito-identity-pool

A [Terraform] module for deploying and managing
[Cognito Identity Pools]
on [Amazon Web Services (AWS)][AWS].

*This module supports Terraform v1.x, v0.15, v0.14, v0.13 as well as v0.12.20 and above
and is compatible with the Terraform AWS provider v3.50 and above.

## Module Features

In contrast to the plain [`cognito_identity_pool`](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cognito_identity_pool)
resource this module has a more secure level of default settings.

# Identity pools

>![Architecture diagram](documentation/Identity_pools.png)

Set up an Amazon Cognito identity pool when you want to authorize authenticated or anonymous users to access your AWS resources. An identity pool issues AWS credentials for your app to serve resources to users. You can authenticate users with a trusted identity provider, like a user pool or a SAML 2.0 service. It can also optionally issue credentials for guest users. Identity pools use both role-based and attribute-based access control to manage your users’ authorization to access your AWS resources.

Identity pools don’t require integration with a user pool. An identity pool can accept authenticated claims directly from both workforce and consumer identity providers.

An Amazon Cognito user pool and identity pool used together

In the diagram that begins this topic, you use Amazon Cognito to authenticate your user and then grant them access to an AWS service.

Your app user signs in through a user pool and receives OAuth 2.0 tokens.

Your app exchanges a user pool token with an identity pool for temporary AWS credentials that you can use with AWS APIs and the AWS Command Line Interface (AWS CLI).

Your app assigns the credentials session to your user, and delivers authorized access to AWS services like Amazon S3 and Amazon DynamoDB.

For more examples that use identity pools and user pools, see Common Amazon Cognito scenarios.

In Amazon Cognito, the security of the cloud obligation of the shared responsibility model is compliant with SOC 1-3, PCI DSS, ISO 27001, and is HIPAA-BAA eligible. You can design your security in the cloud in Amazon Cognito to be compliant with SOC1-3, ISO 27001, and HIPAA-BAA, but not PCI DSS. For more information, see AWS services in scope. See also Regional data considerations.

## Usage
```hcl

module "cognito" {
  
  source = "git::https://gitlab.santanderbr.corp/cpf/terraform-modules/aws-cognito.git?ref=VERSION"

// AWS CONNECTIONS
profile_sigla         = "arq-dev"
region                = "sa-east-1"
profile_shared        = "arq-dev"
shared_account_region = "sa-east-1"

// AWS CONNECTIONS
sigla_compartilhada = "" #PREENCHER SOMENTE SE A SIGLA FOR COMPARTILHADA/ESTRUTURANTE. VALORES VÁLIDOS: EST, SHARED, SHAREDA, SHAREDB

// NAMING VARIABLES
entity                      = "sbr"
app_name                    = "brs"
function                    = "crit"
environment                 = "d1"
resource_sequence           = 16

// TAGS VARIABLES
tags = {
  cia                       = "blm"
  sigla                     = "cpf"
  management_level          = "saas"
  business_service          = "CI0000000000"
  service_component         = "CI0000000000"
  sbr_backup                = "aws"
  name                      = "sbrd1abrcogcpfbrscrit001"
  tracking_code             = "DMN=DMND0000000 - PRJ=PRJ0000000 - FRE=FRE000000 - RPI=RPI0000000 - REQ=REQ000000000"
}

// USER POOL VARIABLES 

name = "user-pool-prj-tools"

deletion_protection                = "INACTIVE"
enable_username_case_sensitivity   = false
advanced_security_mode             = "ENFORCED"

alias_attributes = [
    "email",
    "phone_number",
    "preferred_username",
  ]

  auto_verified_attributes = [
    "email"
  ]

  account_recovery_mechanisms = [
    {
      name     = "verified_email"
      priority = 1
    },
    {
      name     = "verified_phone_number"
      priority = 2
    }
  ]

# If invited by an admin
  invite_email_subject  = "You've been invited to whycloud.io"
  invite_email_message  = "Hi {username}, your temporary password is '{####}'."
  invite_sms_message    = "Hi {username}, your temporary password is '{####}'."

  module_enabled        = true

  domain                = "mydomain"
  default_email_option  = "CONFIRM_WITH_LINK"
  email_subject_by_link = "Your Verification Link"
  email_message_by_link = "Please click the link below to verify your email address. {##Verify Email##}."
  sms_message           = "Your verification code is {####}."

  challenge_required_on_new_device = true
  user_device_tracking             = "USER_OPT_IN"

  # These paramters can be used to configure SES for emails
  # email_sending_account  = "DEVELOPER"
  # reply_to_email_address = "support@mydomain.io"
  # email_from_address     = "noreply@mydomain.io"
  # source_arn       = "arn:aws:ses:us-east-1:999999999999:identity"

# Require MFA
  mfa_configuration        = "ON"
  allow_software_mfa_token = true

  minimum_length                   = 40
  require_lowercase                = true
  require_numbers                  = true
  require_uppercase                = true
  require_symbols                  = true
  temporary_password_validity_days = 3  

create_auth_challenge              = "arn:aws:lambda:sa-east-1:906699411317:function:create_auth_challenge_cognito"
custom_message                     = "arn:aws:lambda:sa-east-1:906699411317:function:custom_message_cognito"
define_auth_challenge              = "arn:aws:lambda:sa-east-1:906699411317:function:define_auth_challenge_cognito"
post_authentication                = "arn:aws:lambda:sa-east-1:906699411317:function:post_authentication_cognito"
post_confirmation                  = "arn:aws:lambda:sa-east-1:906699411317:function:post_confirmation_cognito"
pre_authentication                 = "arn:aws:lambda:sa-east-1:906699411317:function:pre_authentication_cognito"
pre_sign_up                        = "arn:aws:lambda:sa-east-1:906699411317:function:pre_sign_up_cognito"
pre_token_generation               = "arn:aws:lambda:sa-east-1:906699411317:function:pre_token_generation_cognito"
user_migration                     = "arn:aws:lambda:sa-east-1:906699411317:function:user_migration_cognito"
verify_auth_challenge_response     = "arn:aws:lambda:sa-east-1:906699411317:function:verify_auth_challenge_response_cognito"

schema_attributes = [
    {
      name       = "gender", # overwrites the default attribute 'gender'
      type       = "String"
      required   = true
      min_length = 1
      max_length = 2048
    },
    {
      name                     = "alternative_name"
      type                     = "String"
      developer_only_attribute = false,
      mutable                  = true,
      required                 = false,
      min_length               = 0,
      max_length               = 2048
    },
    {
      name      = "friends_count"
      type      = "Number"
      min_value = 0,
      max_value = 100
    },
    {
      name = "is_active"
      type = "Boolean"

    },
    {
      name = "last_seen"
      type = "DateTime"
    }
  ]

  # clients
  clients = [
    {
      allowed_oauth_flows                  = []
      allowed_oauth_flows_user_pool_client = false
      allowed_oauth_scopes                 = []
      callback_urls                        = ["https://mydomain.com/callback"]
      default_redirect_uri                 = "https://mydomain.com/callback"
      explicit_auth_flows                  = []
      generate_secret                      = true
      logout_urls                          = []
      name                                 = "test1"
      read_attributes                      = ["email"]
      supported_identity_providers         = []
      write_attributes                     = []
      access_token_validity                = 1
      id_token_validity                    = 1
      refresh_token_validity               = 60
      token_validity_units = {
        access_token  = "hours"
        id_token      = "hours"
        refresh_token = "days"
      }
    },
    {
      allowed_oauth_flows                  = []
      allowed_oauth_flows_user_pool_client = false
      allowed_oauth_scopes                 = []
      callback_urls                        = ["https://mydomain.com/callback"]
      default_redirect_uri                 = "https://mydomain.com/callback"
      explicit_auth_flows                  = []
      generate_secret                      = false
      logout_urls                          = []
      name                                 = "test2"
      read_attributes                      = []
      supported_identity_providers         = []
      write_attributes                     = []
      refresh_token_validity               = 30
    },
    {
      allowed_oauth_flows                  = ["code", "implicit"]
      allowed_oauth_flows_user_pool_client = true
      allowed_oauth_scopes                 = ["email", "openid"]
      callback_urls                        = ["https://mydomain.com/callback"]
      default_redirect_uri                 = "https://mydomain.com/callback"
      explicit_auth_flows                  = ["CUSTOM_AUTH_FLOW_ONLY", "ADMIN_NO_SRP_AUTH"]
      generate_secret                      = false
      logout_urls                          = ["https://mydomain.com/logout"]
      name                                 = "test3"
      read_attributes                      = ["email", "phone_number"]
      supported_identity_providers         = []
      write_attributes                     = ["email", "gender", "locale", ]
      refresh_token_validity               = 30
    }
  ]

  resource_servers = [
     {
       identifier = "https://api.resourceserver.com"
       name       = "API"
       scopes     = [
         {
           scope_name        = "users:read"
           scope_description = "Read user data"
         },
         {
           scope_name        = "users:write"
           scope_description = "Write user data"
         }
       ]
     }
   ]


allow_admin_create_user_only       = true

// IDENTITY POOL VARIABLES

identity_pool_name                = "portal-cloud-services-tools"
allow_unauthenticated_identities  = false
server_side_token_check           = true
allow_classic_flow                = true

// Cognito Identity Providers

provider_name                     = "Facebook"
provider_type                     = "Facebook"

attribute_mapping = {
    email    = "email"
    username = "id"
    gender   = "gender" 
  }

provider_details = {
   authorize_scopes = "email"
   client_id        = "your client_id"
   client_secret    = "your client_secret"
   api_version      = null 
  }

# user_group
  user_groups = [
    { name        = "mygroup1"
      description = "My group 1"
    },
    { name        = "mygroup2"
      description = "My group 2"
    },
  ]

# users
users = [
    { 
    username          = "teste01"
    attributes = {
    email             = "teste01@hashicorp.com"
    email_verified    = true 
  }
    },
    { 
    username        = "teste02"
    attributes = {
    email             = "teste02@hashicorp.com"
    email_verified    = true 
  }  
    },
    { 
    username        = "teste03"
    attributes = {
    email             = "teste03@hashicorp.com"
    email_verified    = true 
  }  
    },
  ]
}
```

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.14 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 3.29.1 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 5.21.0 |
| <a name="provider_aws.shared"></a> [aws.shared](#provider\_aws.shared) | 5.21.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_tags"></a> [tags](#module\_tags) | git::https://gitlab.santanderbr.corp/cpf/terraform-modules/tag.git | 1.0.0 |

## Resources

| Name | Type |
|------|------|
| [aws_cognito_identity_pool.identity_pool](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cognito_identity_pool) | resource |
| [aws_cognito_identity_pool_roles_attachment.roles_attachment](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cognito_identity_pool_roles_attachment) | resource |
| [aws_cognito_identity_provider.provider](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cognito_identity_provider) | resource |
| [aws_cognito_resource_server.resource_server](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cognito_resource_server) | resource |
| [aws_cognito_user.user](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cognito_user) | resource |
| [aws_cognito_user_group.user_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cognito_user_group) | resource |
| [aws_cognito_user_in_group.user_in_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cognito_user_in_group) | resource |
| [aws_cognito_user_pool.user_pool](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cognito_user_pool) | resource |
| [aws_cognito_user_pool_client.client](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cognito_user_pool_client) | resource |
| [aws_cognito_user_pool_domain.domain](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cognito_user_pool_domain) | resource |
| [aws_iam_role.authenticated](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.unauthenticated](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_lambda_permission.allow_cognito_custom_message](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_permission) | resource |
| [aws_lambda_permission.allow_cognito_pre_sign_up](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_permission) | resource |
| [aws_caller_identity.profile_shared](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_caller_identity.profile_sigla](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_iam_policy_document.assume_authenticated_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.assume_unauthenticated_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_account_recovery_mechanisms"></a> [account\_recovery\_mechanisms](#input\_account\_recovery\_mechanisms) | (Optional) A list of recovery\_mechanisms which are defined by a `name` and its `priority`. Valid values for `name` are veri  fied\_email, verified\_phone\_number, and admin\_only. | `any` | `[]` | no |
| <a name="input_advanced_security_mode"></a> [advanced\_security\_mode](#input\_advanced\_security\_mode) | (Optional) The mode for advanced security, must be one of `OFF`, `AUDIT` or `ENFORCED`. Additional pricing applies for Amazon Cognito advanced security features. For details see https://aws.amazon.com/cognito/pricing/ | `string` | `"OFF"` | no |
| <a name="input_alias_attributes"></a> [alias\_attributes](#input\_alias\_attributes) | (Optional) Attributes supported as an alias for this user pool. Possible values: 'phone\_number', 'email', or 'preferred\_username'. Conflicts with username\_attributes. | `set(string)` | `null` | no |
| <a name="input_allow_admin_create_user_only"></a> [allow\_admin\_create\_user\_only](#input\_allow\_admin\_create\_user\_only) | (Optional) Set to True if only the administrator is allowed to create user profiles. Set to False if users can sign themselves up via an app. | `bool` | `true` | no |
| <a name="input_allow_classic_flow"></a> [allow\_classic\_flow](#input\_allow\_classic\_flow) | (Optional) - Enables or disables the classic / basic authentication flow. Default is false. | `bool` | `true` | no |
| <a name="input_allow_software_mfa_token"></a> [allow\_software\_mfa\_token](#input\_allow\_software\_mfa\_token) | (Optional) Boolean whether to enable software token Multi-Factor (MFA) tokens, such as Time-based One-Time Password (TOTP). To disable software token MFA when 'sms\_configuration' is not present, the 'mfa\_configuration' argument must be set to OFF and the 'software\_token\_mfa\_configuration' configuration block must be fully removed. | `bool` | `true` | no |
| <a name="input_allow_unauthenticated_identities"></a> [allow\_unauthenticated\_identities](#input\_allow\_unauthenticated\_identities) | Whether the identity pool supports unauthenticated logins or not.(true or false) | `bool` | `false` | no |
| <a name="input_app_name"></a> [app\_name](#input\_app\_name) | (Optional) App acronym of the resource. Used for Naming. (3 characters) | `string` | `"brs"` | no |
| <a name="input_attribute_mapping"></a> [attribute\_mapping](#input\_attribute\_mapping) | (Optional) Map of attribute mapping of user pool attributes | `map(string)` | `{}` | no |
| <a name="input_attributes"></a> [attributes](#input\_attributes) | The attributes of the user | `map(string)` | `{}` | no |
| <a name="input_auto_verified_attributes"></a> [auto\_verified\_attributes](#input\_auto\_verified\_attributes) | (Optional) The attributes to be auto-verified. Possible values: 'email', 'phone\_number'. | `set(string)` | <pre>[<br>  "email"<br>]</pre> | no |
| <a name="input_certificate_arn"></a> [certificate\_arn](#input\_certificate\_arn) | (Optional) The ARN of an ISSUED ACM certificate in us-east-1 for a custom domain. | `string` | `null` | no |
| <a name="input_challenge_required_on_new_device"></a> [challenge\_required\_on\_new\_device](#input\_challenge\_required\_on\_new\_device) | (Optional) Indicates whether a challenge is required on a new device. Only applicable to a new device. | `bool` | `true` | no |
| <a name="input_client_access_token_validity"></a> [client\_access\_token\_validity](#input\_client\_access\_token\_validity) | Time limit, between 5 minutes and 1 day, after which the access token is no longer valid and cannot be used. This value will be overridden if you have entered a value in `token_validity_units`. | `number` | `60` | no |
| <a name="input_client_allowed_oauth_flows"></a> [client\_allowed\_oauth\_flows](#input\_client\_allowed\_oauth\_flows) | The name of the application client | `list(string)` | `[]` | no |
| <a name="input_client_allowed_oauth_flows_user_pool_client"></a> [client\_allowed\_oauth\_flows\_user\_pool\_client](#input\_client\_allowed\_oauth\_flows\_user\_pool\_client) | Whether the client is allowed to follow the OAuth protocol when interacting with Cognito user pools | `bool` | `true` | no |
| <a name="input_client_allowed_oauth_scopes"></a> [client\_allowed\_oauth\_scopes](#input\_client\_allowed\_oauth\_scopes) | List of allowed OAuth scopes (phone, email, openid, profile, and aws.cognito.signin.user.admin) | `list(string)` | `[]` | no |
| <a name="input_client_auth_session_validity"></a> [client\_auth\_session\_validity](#input\_client\_auth\_session\_validity) | Amazon Cognito creates a session token for each API request in an authentication flow. AuthSessionValidity is the duration, in minutes, of that session token. Your user pool native user must respond to each authentication challenge before the session expires. Valid values between 3 and 15. Default value is 3. | `number` | `3` | no |
| <a name="input_client_callback_urls"></a> [client\_callback\_urls](#input\_client\_callback\_urls) | List of allowed callback URLs for the identity providers | `list(string)` | `[]` | no |
| <a name="input_client_default_redirect_uri"></a> [client\_default\_redirect\_uri](#input\_client\_default\_redirect\_uri) | The default redirect URI. Must be in the list of callback URLs | `string` | `""` | no |
| <a name="input_client_enable_token_revocation"></a> [client\_enable\_token\_revocation](#input\_client\_enable\_token\_revocation) | Whether the client token can be revoked | `bool` | `true` | no |
| <a name="input_client_explicit_auth_flows"></a> [client\_explicit\_auth\_flows](#input\_client\_explicit\_auth\_flows) | List of authentication flows (ADMIN\_NO\_SRP\_AUTH, CUSTOM\_AUTH\_FLOW\_ONLY, USER\_PASSWORD\_AUTH) | `list(string)` | `[]` | no |
| <a name="input_client_generate_secret"></a> [client\_generate\_secret](#input\_client\_generate\_secret) | Should an application secret be generated | `bool` | `true` | no |
| <a name="input_client_id_token_validity"></a> [client\_id\_token\_validity](#input\_client\_id\_token\_validity) | Time limit, between 5 minutes and 1 day, after which the ID token is no longer valid and cannot be used. Must be between 5 minutes and 1 day. Cannot be greater than refresh token expiration. This value will be overridden if you have entered a value in `token_validity_units`. | `number` | `60` | no |
| <a name="input_client_logout_urls"></a> [client\_logout\_urls](#input\_client\_logout\_urls) | List of allowed logout URLs for the identity providers | `list(string)` | `[]` | no |
| <a name="input_client_name"></a> [client\_name](#input\_client\_name) | The name of the application client | `string` | `null` | no |
| <a name="input_client_prevent_user_existence_errors"></a> [client\_prevent\_user\_existence\_errors](#input\_client\_prevent\_user\_existence\_errors) | Choose which errors and responses are returned by Cognito APIs during authentication, account confirmation, and password recovery when the user does not exist in the user pool. When set to ENABLED and the user does not exist, authentication returns an error indicating either the username or password was incorrect, and account confirmation and password recovery return a response indicating a code was sent to a simulated destination. When set to LEGACY, those APIs will return a UserNotFoundException exception if the user does not exist in the user pool. | `string` | `null` | no |
| <a name="input_client_read_attributes"></a> [client\_read\_attributes](#input\_client\_read\_attributes) | List of user pool attributes the application client can read from | `list(string)` | `[]` | no |
| <a name="input_client_refresh_token_validity"></a> [client\_refresh\_token\_validity](#input\_client\_refresh\_token\_validity) | The time limit in days refresh tokens are valid for. Must be between 60 minutes and 3650 days. This value will be overridden if you have entered a value in `token_validity_units` | `number` | `30` | no |
| <a name="input_client_supported_identity_providers"></a> [client\_supported\_identity\_providers](#input\_client\_supported\_identity\_providers) | List of provider names for the identity providers that are supported on this client | `list(string)` | `[]` | no |
| <a name="input_client_token_validity_units"></a> [client\_token\_validity\_units](#input\_client\_token\_validity\_units) | Configuration block for units in which the validity times are represented in. Valid values for the following arguments are: `seconds`, `minutes`, `hours` or `days`. | `any` | <pre>{<br>  "access_token": "minutes",<br>  "id_token": "minutes",<br>  "refresh_token": "days"<br>}</pre> | no |
| <a name="input_client_write_attributes"></a> [client\_write\_attributes](#input\_client\_write\_attributes) | List of user pool attributes the application client can write to | `list(string)` | `[]` | no |
| <a name="input_clients"></a> [clients](#input\_clients) | (Optional) A list of objects with the clients definitions. | `any` | `[]` | no |
| <a name="input_cognito_identity_providers"></a> [cognito\_identity\_providers](#input\_cognito\_identity\_providers) | An array of Amazon Cognito Identity user pools and their client IDs. | `map(string)` | `{}` | no |
| <a name="input_create_auth_challenge"></a> [create\_auth\_challenge](#input\_create\_auth\_challenge) | (Optional) The ARN of an AWS Lambda creating an authentication challenge. | `string` | `null` | no |
| <a name="input_custom_message"></a> [custom\_message](#input\_custom\_message) | (Optional) The ARN of a custom message AWS Lambda trigger. | `string` | `null` | no |
| <a name="input_default_client_access_token_validity"></a> [default\_client\_access\_token\_validity](#input\_default\_client\_access\_token\_validity) | (Optional) Time limit, between 5 minutes and 1 day, after which the access token is no longer valid and cannot be used. This value will be overridden if you have entered a value in 'default\_client\_token\_validity\_units'. | `number` | `null` | no |
| <a name="input_default_client_allowed_oauth_flows"></a> [default\_client\_allowed\_oauth\_flows](#input\_default\_client\_allowed\_oauth\_flows) | (Optional) List of allowed OAuth flows. Possible flows are 'code', 'implicit', and 'client\_credentials'. | `list(string)` | `null` | no |
| <a name="input_default_client_allowed_oauth_flows_user_pool_client"></a> [default\_client\_allowed\_oauth\_flows\_user\_pool\_client](#input\_default\_client\_allowed\_oauth\_flows\_user\_pool\_client) | (Optional) Whether the client is allowed to follow the OAuth protocol when interacting with Cognito User Pools. | `bool` | `null` | no |
| <a name="input_default_client_allowed_oauth_scopes"></a> [default\_client\_allowed\_oauth\_scopes](#input\_default\_client\_allowed\_oauth\_scopes) | (Optional) List of allowed OAuth scopes. Possible values are 'phone', 'email', 'openid', 'profile', and 'aws.cognito.signin.user.admin'. | `list(string)` | `null` | no |
| <a name="input_default_client_callback_urls"></a> [default\_client\_callback\_urls](#input\_default\_client\_callback\_urls) | (Optional) List of allowed callback URLs for the identity providers. | `list(string)` | `null` | no |
| <a name="input_default_client_default_redirect_uri"></a> [default\_client\_default\_redirect\_uri](#input\_default\_client\_default\_redirect\_uri) | (Optional) The default redirect URI. Must be in the list of callback URLs. | `string` | `null` | no |
| <a name="input_default_client_enable_token_revocation"></a> [default\_client\_enable\_token\_revocation](#input\_default\_client\_enable\_token\_revocation) | (Optional) Enables or disables token revocation. | `bool` | `null` | no |
| <a name="input_default_client_explicit_auth_flows"></a> [default\_client\_explicit\_auth\_flows](#input\_default\_client\_explicit\_auth\_flows) | (Optional) List of authentication flows. Possible values are 'ADMIN\_NO\_SRP\_AUTH', 'CUSTOM\_AUTH\_FLOW\_ONLY', 'USER\_PASSWORD\_AUTH', 'ALLOW\_ADMIN\_USER\_PASSWORD\_AUTH', 'ALLOW\_CUSTOM\_AUTH', 'ALLOW\_USER\_PASSWORD\_AUTH', 'ALLOW\_USER\_SRP\_AUTH', and 'ALLOW\_REFRESH\_TOKEN\_AUTH'. | `list(string)` | `null` | no |
| <a name="input_default_client_generate_secret"></a> [default\_client\_generate\_secret](#input\_default\_client\_generate\_secret) | (Optional) Boolean flag for generating an application secret. | `bool` | `null` | no |
| <a name="input_default_client_id_token_validity"></a> [default\_client\_id\_token\_validity](#input\_default\_client\_id\_token\_validity) | (Optional) Time limit, between 5 minutes and 1 day, after which the ID token is no longer valid and cannot be used. This value will be overridden if you have entered a value in 'default\_client\_token\_validity\_units'. | `number` | `null` | no |
| <a name="input_default_client_logout_urls"></a> [default\_client\_logout\_urls](#input\_default\_client\_logout\_urls) | (Optional) List of allowed logout URLs for the identity providers. | `list(string)` | `null` | no |
| <a name="input_default_client_prevent_user_existence_errors"></a> [default\_client\_prevent\_user\_existence\_errors](#input\_default\_client\_prevent\_user\_existence\_errors) | (Optional) Choose which errors and responses are returned by Cognito APIs during authentication, account confirmation, and password recovery when the user does not exist in the Cognito User Pool. When set to 'ENABLED' and the user does not exist, authentication returns an error indicating either the username or password was incorrect, and account confirmation and password recovery return a response indicating a code was sent to a simulated destination. When set to 'LEGACY', those APIs will return a 'UserNotFoundException' exception if the user does not exist in the Cognito User Pool. | `string` | `null` | no |
| <a name="input_default_client_read_attributes"></a> [default\_client\_read\_attributes](#input\_default\_client\_read\_attributes) | (Optional) List of Cognito User Pool attributes the application client can read from. | `list(string)` | `null` | no |
| <a name="input_default_client_refresh_token_validity"></a> [default\_client\_refresh\_token\_validity](#input\_default\_client\_refresh\_token\_validity) | (Optional) The time limit in days refresh tokens are valid for. | `number` | `30` | no |
| <a name="input_default_client_supported_identity_providers"></a> [default\_client\_supported\_identity\_providers](#input\_default\_client\_supported\_identity\_providers) | (Optional) List of provider names for the identity providers that are supported on this client. | `list(string)` | `null` | no |
| <a name="input_default_client_token_validity_units"></a> [default\_client\_token\_validity\_units](#input\_default\_client\_token\_validity\_units) | (Optional) Configuration block for units in which the validity times are represented in. | `any` | `null` | no |
| <a name="input_default_client_write_attributes"></a> [default\_client\_write\_attributes](#input\_default\_client\_write\_attributes) | (Optional) List of Cognito User Pool attributes the application client can write to. | `list(string)` | `null` | no |
| <a name="input_default_email_option"></a> [default\_email\_option](#input\_default\_email\_option) | (Optional) The default email option. Must be either `CONFIRM_WITH_CODE` or `CONFIRM_WITH_LINK`. | `string` | `"CONFIRM_WITH_CODE"` | no |
| <a name="input_define_auth_challenge"></a> [define\_auth\_challenge](#input\_define\_auth\_challenge) | (Optional) The ARN of an AWS Lambda that defines the authentication challenge. | `string` | `null` | no |
| <a name="input_deletion_protection"></a> [deletion\_protection](#input\_deletion\_protection) | When active, DeletionProtection prevents accidental deletion of your user pool. Before you can delete a user pool that you have protected against deletion, you must deactivate this feature. Valid values are ACTIVE and INACTIVE, Default value is INACTIVE. | `string` | `"INACTIVE"` | no |
| <a name="input_developer_provider_name"></a> [developer\_provider\_name](#input\_developer\_provider\_name) | The domain by which Cognito will refer to your users. This name acts as a placeholder that allows your backend and the Cognito service to communicate about the developer provider. | `string` | `""` | no |
| <a name="input_device_configuration"></a> [device\_configuration](#input\_device\_configuration) | The configuration for the user pool's device tracking | `list(string)` | `[]` | no |
| <a name="input_domain"></a> [domain](#input\_domain) | (Optional) Type a domain prefix to use for the sign-up and sign-in pages that are hosted by Amazon Cognito, e.g. 'https://{YOUR_PREFIX}.auth.eu-west-1.amazoncognito.com'. The prefix must be unique across the selected AWS Region. Domain names can only contain lower-case letters, numbers, and hyphens. | `string` | `null` | no |
| <a name="input_email_from_address"></a> [email\_from\_address](#input\_email\_from\_address) | (Optional) - Sender’s email address or sender’s name with their email address (e.g. 'john@smith.com' or 'John Smith <john@smith.com>'). | `string` | `null` | no |
| <a name="input_email_message"></a> [email\_message](#input\_email\_message) | (Optional) The email message template. Must contain the {####} placeholder. | `string` | `"Your verification code is {####}."` | no |
| <a name="input_email_message_by_link"></a> [email\_message\_by\_link](#input\_email\_message\_by\_link) | (Optional) The email message template for sending a confirmation link to the user, it must contain the {##Any Text##} placeholder. | `string` | `"Please click the link below to verify your email address. {##Verify Email##}."` | no |
| <a name="input_email_sending_account"></a> [email\_sending\_account](#input\_email\_sending\_account) | (Optional) The email delivery method to use. 'COGNITO\_DEFAULT' for the default email functionality built into Cognito or 'DEVELOPER' to use your Amazon SES configuration. | `string` | `"COGNITO_DEFAULT"` | no |
| <a name="input_email_subject"></a> [email\_subject](#input\_email\_subject) | (Optional) The subject line for the email message template. | `string` | `"Your Verification Code"` | no |
| <a name="input_email_subject_by_link"></a> [email\_subject\_by\_link](#input\_email\_subject\_by\_link) | (Optional) The subject line for the email message template for sending a confirmation link to the user. | `string` | `"Your Verification Link"` | no |
| <a name="input_enable_username_case_sensitivity"></a> [enable\_username\_case\_sensitivity](#input\_enable\_username\_case\_sensitivity) | (Optional) Specifies whether username case sensitivity will be applied for all users in the user pool through Cognito APIs. | `bool` | `false` | no |
| <a name="input_entity"></a> [entity](#input\_entity) | (Required) Santander entity code. Used for Naming. (3 characters) | `string` | `"sbr"` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | (Required). Santander environment code. Used for Naming. (2 characters) | `string` | n/a | yes |
| <a name="input_function"></a> [function](#input\_function) | (Optional) App function of the resource. Used for Naming. (4 characters) | `string` | `"comm"` | no |
| <a name="input_identity_pool_name"></a> [identity\_pool\_name](#input\_identity\_pool\_name) | The cognito identity pool name | `string` | `"portal-cloud-services-tools"` | no |
| <a name="input_invite_email_message"></a> [invite\_email\_message](#input\_invite\_email\_message) | (Optional) The message template for email messages. Must contain {username} and {####} placeholders, for username and temporary password, respectively. | `string` | `"Your username is {username} and your temporary password is '{####}'."` | no |
| <a name="input_invite_email_subject"></a> [invite\_email\_subject](#input\_invite\_email\_subject) | (Optional) The subject for email messages. | `string` | `"Your new account."` | no |
| <a name="input_invite_sms_message"></a> [invite\_sms\_message](#input\_invite\_sms\_message) | (Optional) The message template for SMS messages. Must contain {username} and {####} placeholders, for username and temporary password, respectively. | `string` | `"Your username is {username} and your temporary password is '{####}'."` | no |
| <a name="input_mfa_configuration"></a> [mfa\_configuration](#input\_mfa\_configuration) | Multi-Factor Authentication (MFA) configuration for the User Pool. Valid values: 'ON', 'OFF' or 'OPTIONAL'. 'ON' and 'OPTIONAL' require at least one of 'sms\_configuration' or 'software\_token\_mfa\_configuration' to be configured. | `string` | `"OPTIONAL"` | no |
| <a name="input_minimum_length"></a> [minimum\_length](#input\_minimum\_length) | (Optional) The minimum length of the password policy that you have set. | `number` | `20` | no |
| <a name="input_module_depends_on"></a> [module\_depends\_on](#input\_module\_depends\_on) | (Optional) A list of external resources the module depends\_on. | `any` | `[]` | no |
| <a name="input_module_enabled"></a> [module\_enabled](#input\_module\_enabled) | (Optional) Whether to create resources within the module or not. | `bool` | `true` | no |
| <a name="input_name"></a> [name](#input\_name) | (Required) The name of the user pool. | `string` | n/a | yes |
| <a name="input_openid_connect_provider_arns"></a> [openid\_connect\_provider\_arns](#input\_openid\_connect\_provider\_arns) | A list of OpendID Connect provider ARNs. | `list(string)` | `[]` | no |
| <a name="input_post_authentication"></a> [post\_authentication](#input\_post\_authentication) | (Optional) The ARN of a post-authentication AWS Lambda trigger. | `string` | `null` | no |
| <a name="input_post_confirmation"></a> [post\_confirmation](#input\_post\_confirmation) | (Optional) The ARN of a post-confirmation AWS Lambda trigger. | `string` | `null` | no |
| <a name="input_pre_authentication"></a> [pre\_authentication](#input\_pre\_authentication) | (Optional) The ARN of a pre-authentication AWS Lambda trigger. | `string` | `null` | no |
| <a name="input_pre_sign_up"></a> [pre\_sign\_up](#input\_pre\_sign\_up) | (Optional) The ARN of a pre-registration AWS Lambda trigger. | `string` | `null` | no |
| <a name="input_pre_token_generation"></a> [pre\_token\_generation](#input\_pre\_token\_generation) | (Optional) The ARN of an AWS Lambda that allows customization of identity token claims before token generation. | `string` | `null` | no |
| <a name="input_profile_security"></a> [profile\_security](#input\_profile\_security) | (Required) AWS Profile for Security Account. | `string` | `"security"` | no |
| <a name="input_profile_shared"></a> [profile\_shared](#input\_profile\_shared) | (Required) AWS Profile for Shared Account. | `string` | `"shared"` | no |
| <a name="input_profile_sigla"></a> [profile\_sigla](#input\_profile\_sigla) | (Required) AWS Profile for Sigla/Channel Account. | `string` | `null` | no |
| <a name="input_provider_details"></a> [provider\_details](#input\_provider\_details) | (Optional) Map of attribute mapping of user pool attributes | `map(string)` | `{}` | no |
| <a name="input_provider_name"></a> [provider\_name](#input\_provider\_name) | (Required) Provider name | `string` | `"ProviderTools"` | no |
| <a name="input_provider_type"></a> [provider\_type](#input\_provider\_type) | (Required) Provider type | `string` | `"Google"` | no |
| <a name="input_region"></a> [region](#input\_region) | (Optional) Region where the resource will be launched. | `string` | `"sa-east-1"` | no |
| <a name="input_reply_to_email_address"></a> [reply\_to\_email\_address](#input\_reply\_to\_email\_address) | (Optional) - The REPLY-TO email address. | `string` | `null` | no |
| <a name="input_require_lowercase"></a> [require\_lowercase](#input\_require\_lowercase) | (Optional) Whether you have required users to use at least one lowercase letter in their password. | `bool` | `true` | no |
| <a name="input_require_numbers"></a> [require\_numbers](#input\_require\_numbers) | (Optional) Whether you have required users to use at least one number in their password. | `bool` | `true` | no |
| <a name="input_require_symbols"></a> [require\_symbols](#input\_require\_symbols) | (Optional) Whether you have required users to use at least one symbol in their password. | `bool` | `true` | no |
| <a name="input_require_uppercase"></a> [require\_uppercase](#input\_require\_uppercase) | (Optional) Whether you have required users to use at least one uppercase letter in their password. | `bool` | `true` | no |
| <a name="input_resource_sequence"></a> [resource\_sequence](#input\_resource\_sequence) | (Required) Sequence number of the resource. If you have more than one resource, send the sequence accordingly so that names dont clash. | `number` | n/a | yes |
| <a name="input_resource_servers"></a> [resource\_servers](#input\_resource\_servers) | (Optional) A list of objects with resource server definitions. | `any` | `[]` | no |
| <a name="input_saml_provider_arns"></a> [saml\_provider\_arns](#input\_saml\_provider\_arns) | An array of Amazon Resource Names (ARNs) of the SAML provider for your identity. | `list(string)` | `[]` | no |
| <a name="input_schema_attributes"></a> [schema\_attributes](#input\_schema\_attributes) | (Optional) A list of schema attributes of a user pool. You can add a maximum of 25 custom attributes. | `any` | `[]` | no |
| <a name="input_server_side_token_check"></a> [server\_side\_token\_check](#input\_server\_side\_token\_check) | Whether server-side token validation is enabled for the identity provider’s token or not.(true or false) | `bool` | `true` | no |
| <a name="input_shared_account_region"></a> [shared\_account\_region](#input\_shared\_account\_region) | (Optional) Shared account region. | `string` | `"sa-east-1"` | no |
| <a name="input_sigla_compartilhada"></a> [sigla\_compartilhada](#input\_sigla\_compartilhada) | (Required) Variable to validate if the abbreviation is shared/structuring | `string` | `"EST"` | no |
| <a name="input_sms_authentication_message"></a> [sms\_authentication\_message](#input\_sms\_authentication\_message) | (Optional) A string representing the SMS authentication message. The message must contain the {####} placeholder, which will be replaced with the authentication code. | `string` | `"Your temporary password is {####}."` | no |
| <a name="input_sms_configuration"></a> [sms\_configuration](#input\_sms\_configuration) | (Optional) The `sms_configuration` with the `external_id` parameter used in iam role trust relationships and the `sns_caller_arn` parameter to set he arn of the amazon sns caller. this is usually the iam role that you've given cognito permission to assume. | <pre>object({<br>    # The external ID used in IAM role trust relationships. For more information about using external IDs, see https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_create_for-user_externalid.html<br>    external_id = string<br>    # The ARN of the Amazon SNS caller. This is usually the IAM role that you've given Cognito permission to assume.<br>    sns_caller_arn = string<br>  })</pre> | `null` | no |
| <a name="input_sms_message"></a> [sms\_message](#input\_sms\_message) | (Optional) The SMS message template. Must contain the {####} placeholder, which will be replaced with the verification code. Can also contain the {username} placeholder which will be replaced with the username. | `string` | `"Your verification code is {####}."` | no |
| <a name="input_source_arn"></a> [source\_arn](#input\_source\_arn) | (Optional) - The ARN of the email source. | `string` | `null` | no |
| <a name="input_supported_login_providers"></a> [supported\_login\_providers](#input\_supported\_login\_providers) | Key-Value pairs mapping provider names to provider app IDs. | `map(string)` | `{}` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Required) Tags as defined by Global: https://confluence.alm.europe.cloudcenter.corp/x/XEGqCg | `map(string)` | n/a | yes |
| <a name="input_temporary_password_validity_days"></a> [temporary\_password\_validity\_days](#input\_temporary\_password\_validity\_days) | (Optional) In the password policy you have set, refers to the number of days a temporary password is valid. If the user does not sign-in during this time, their password will need to be reset by an administrator. | `number` | `1` | no |
| <a name="input_user_device_tracking"></a> [user\_device\_tracking](#input\_user\_device\_tracking) | (Optional) Configure tracking of user devices. Set to 'OFF' to disable tracking, 'ALWAYS' to track all devices or 'USER\_OPT\_IN' to only track when user opts in. | `string` | `"USER_OPT_IN"` | no |
| <a name="input_user_group"></a> [user\_group](#input\_user\_group) | (Required) The username for the user. Must be unique within the user pool. Must be a UTF-8 string between 1 and 128 characters. After the user is created, the username cannot be changed. | `string` | `"user-group-prj-tools"` | no |
| <a name="input_user_group_description"></a> [user\_group\_description](#input\_user\_group\_description) | The description of the user group | `string` | `null` | no |
| <a name="input_user_group_name"></a> [user\_group\_name](#input\_user\_group\_name) | The name of the user group | `string` | `null` | no |
| <a name="input_user_group_precedence"></a> [user\_group\_precedence](#input\_user\_group\_precedence) | The precedence of the user group | `number` | `null` | no |
| <a name="input_user_group_role_arn"></a> [user\_group\_role\_arn](#input\_user\_group\_role\_arn) | The ARN of the IAM role to be associated with the user group | `string` | `null` | no |
| <a name="input_user_groups"></a> [user\_groups](#input\_user\_groups) | A container with the user\_groups definitions | `list(any)` | `[]` | no |
| <a name="input_user_migration"></a> [user\_migration](#input\_user\_migration) | (Optional) The ARN of the user migration AWS Lambda config type. | `string` | `null` | no |
| <a name="input_username"></a> [username](#input\_username) | The name of the user group | `string` | `null` | no |
| <a name="input_username_attributes"></a> [username\_attributes](#input\_username\_attributes) | (Optional) Specifies whether email addresses or phone numbers can be specified as usernames when a user signs up. Conflicts with alias\_attributes. | `set(string)` | `null` | no |
| <a name="input_users"></a> [users](#input\_users) | A container with the user\_groups definitions | `list(any)` | `[]` | no |
| <a name="input_verify_auth_challenge_response"></a> [verify\_auth\_challenge\_response](#input\_verify\_auth\_challenge\_response) | (Optional) The ARN of an AWS Lambda that verifies the authentication challenge response. | `string` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_domain"></a> [domain](#output\_domain) | The full `aws_cognito_user_pool` object. |
| <a name="output_module_enabled"></a> [module\_enabled](#output\_module\_enabled) | Whether the module is enabled |
| <a name="output_user_pool"></a> [user\_pool](#output\_user\_pool) | The full `aws_cognito_user_pool` object. |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->

# **Security Framework**
This section explains how the different aspects to have into account in order to meet the Security Control for Cloud for this Certified Service. 

## CERTIFICATE LEVEL: ADVANCED
## Security Controls based on Security Control for Cloud

### Foundation (**F**) Controls for Rated Workloads
|SF#|What|How it is implemented in the Product|Who|
|--|:---|:---|:--|
|SF1|IAM on all accounts|IAM permissions based on [roles](https://docs.aws.amazon.com/cognito/latest/developerguide/security-iam.html)|CCoE <br> Entity|
|SF2|MFA on accounts|This is governed by AWS IAM - [Adding MFA to a user pool](https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-settings-mfa.html)| CISO <br> CCoE <br> Entity|
|SF3|Platform Activity Logs & Security Monitoring|Platform logs and security monitoring provided by Platform. [CloudWatch](https://docs.aws.amazon.com/cognito/latest/developerguide/tracking-quotas-and-usage-in-cloud-watch-and-service-quotas.html) and [CloudTrail](https://docs.aws.amazon.com/cognito/latest/developerguide/logging-using-cloudtrail.html)|CCoE <br> Entity <br> CISO|
|SF4|Virus/Malware Protection on IaaS|No AWS managed service is responsible for this layer of security and this protection is not necessary for Cognito|CCoE <br> Entity <br> CISO|
|SF5|Authenticate all connections|[Authentication with a user pool](https://docs.aws.amazon.com/cognito/latest/developerguide/authentication.html) - [Authentication with a identity pool](https://docs.aws.amazon.com/cognito/latest/developerguide/external-identity-providers.html) - [Identity pools concepts](https://docs.aws.amazon.com/cognito/latest/developerguide/concepts.html)|CCoE Entity|</span>
|SF6|Isolated environments at network levels|Infrastructure security in Amazon Cognito [Infrastructure security](https://docs.aws.amazon.com/cognito/latest/developerguide/infrastructure-security.html)|CCoE <br> CISO <br> Entity |
|SF7|Security Configuration & Patch Management|As a managed service, Amazon Cognito is protected by the AWS global network security procedures described in the [Amazon Web Services: Overview of Security Processes whitepaper](https://d0.awsstatic.com/whitepapers/Security/AWS_Security_Whitepaper.pdf)|CCoE <br> Entity|
|SF8|Privileged Access Management|IAM permissions based on roles|CCoE <br> CISO|

### Medium (**M**) Controls for Rated Workloads
|SM#|What|How it is implemented in the Product|Who|
|--|:---|:---|:--|
|SM1|IAM| Use IAM/RBAC configuration. (Use IAM roles for applications and AWS services which require Amazon Cognito access)|CCoE <br> Entity|
|SM2|Encrypt data at rest|Data within Amazon Cognito is encrypted at rest in accordance with industry standards. [Encryption at rest](https://docs.aws.amazon.com/cognito/latest/developerguide/data-protection.html)|CCoE|
|SM3|Encrypt data in transit over private interconnections|As a managed service, Amazon Cognito is protected by AWS global network security. For information about AWS security services and how AWS protects infrastructure, see AWS Cloud Security. To design your AWS environment using the best practices for infrastructure security, see Infrastructure Protection in Security Pillar AWS Well‐Architected Framework. [Encryption in transit](https://docs.aws.amazon.com/cognito/latest/developerguide/data-protection.html)|Entity <br> CCoE|
|SM4|Control resource geographical location|The region where the Cognito is created is previously define as a variable in Terraform code. The current support values are sa-east-1 and us-east-1.|CCoE <br> CISO|
|SM5|Privileged Access Management|Covered by SF1, SF2 and SF3|CCoE <br> CISO|

### Application (**P**) Controls for Rated Workloads
|SP#|What|How it is implemented in the Product|Who|
|--|:---|:---|:--|
|SP1|Resource tagging for all resources|The implementation will be done using a terraform module following the references to [HCF Naming and Tagging Chapter v1.3](https://confluence.ci.gsnet.corp/x/l7IiCQ)|CCoE <br> CISO|
|SP2|Segregation of Duties| Use IAM/RBAC configuration. "Access is based on the principle of least privilege assigned to roles" according to the AWS Well-Architected Framework – Implement a Strong identity Foundation.|CCoE <br> CISO <br> Entity|
|SP3|Vulnerability Management| AWS handles basic security tasks like guest operating system (OS) and database patching, firewall configuration, and disaster recovery. These procedures have been reviewed and certified by the appropriate third parties. For more details, see the following resources: Compliance validation for Amazon Cognito and Shared Responsibility Model. [Configuration and vulnerability analysis in Amazon Cognito user pools](https://docs.aws.amazon.com/cognito/latest/developerguide/vulnerability-analysis-and-management.html)|CCoE <br> CISO <br> Entity|
|SP4|Service Logs & Security Monitoring|Platform logs and security monitoring provided by Platform. [CloudWatch](https://docs.aws.amazon.com/cognito/latest/developerguide/tracking-quotas-and-usage-in-cloud-watch-and-service-quotas.html) and [CloudTrail](https://docs.aws.amazon.com/cognito/latest/developerguide/logging-using-cloudtrail.html)|CCoE <br> Entity <br> CISO|
|SP5|Network Security|[Security in Amazon Cognito](https://docs.aws.amazon.com/cognito/latest/developerguide/security.html)|CCoE <br> Entity <br> CISO|
|SP5.1| Inbound and outbound traffic: CSP Private zone to Santander On-premises| Protection between zones provided by platform.|
|SP5.2| Inbound and outbound traffic: between CSP Private zones of different entities| Protection between zones provided by platform.|
|SP5.3| Inbound and outbound traffic: between CSP Private zones of the same entity | Protection between zones provided by platform.|
|SP5.4| Inbound traffic: Internet to CSP Public zone |Protection between zones provided by platform.|
|SP5.5| Outbound traffic: From CSP Public/Private zone to Internet | N/A|
|SP5.6| Control all DNS resolutions and NTP consumption in CSP Private zone| N/A
|SP6|Advanced Malware Protection on IaaS|N/A. Nothing can be done from the terraform automation.|CCoE <br> Entity <br> CISO|
|SP7|Cyber incidents management & Digital evidences gathering|Capacity provided from TLZ.|CISO <br> Entity|
|SP8|Encrypt data in transit over public interconnections|Depend of Development team|Entity <br> CCoE|
|SP9|Static Application Security Testing (SAST)| Evaluated by Sentinel (Terraform Enterprise) and by Dome9 (Check Point) | Entity|


### Advanced (**A**) Controls for Rated Workloads
|SM#|What|How it is implemented in the Product|Who|
|--|:---|:---|:--|
|SA1|IAM| IAM permissions based on [roles](https://docs.aws.amazon.com/cognito/latest/developerguide/security-iam.html)|CCoE <br> Entity|
|SA2|Encrypt data at rest|Data within Amazon Cognito is encrypted at rest in accordance with industry standards. [Encryption at rest](https://docs.aws.amazon.com/cognito/latest/developerguide/data-protection.html)|CCoE|
|SA3|Encrypt data in transit over private interconnections| As a managed service, Amazon Cognito is protected by AWS global network security. For information about AWS security services and how AWS protects infrastructure, see AWS Cloud Security. To design your AWS environment using the best practices for infrastructure security, see Infrastructure Protection in Security Pillar AWS Well‐Architected Framework. [Encryption in transit](https://docs.aws.amazon.com/cognito/latest/developerguide/data-protection.html)|Entity <br> CCoE|
|SA4|Santander managed keys with HSM and BYOK|Possible by configuring a BYOK key ARN|CCoE <br> CISO <br> Entity|
|SA5|Control resource geographical location|Certified Product location can be configured using product deployment parameters|CCoE <br> CISO|
|SA6|Cardholder and auth sensitive data| N/A. Provided by the environment.|Entity|
|SA7|Access control to data with MFA|[Adding MFA to a user pool](https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-settings-mfa.html)|CISO <br> CCoE <br> Entity|


### Critical (**C**) Controls for Rated Workloads
|SM#|What|How it is implemented in the Product|Who|
|--|:---|:---|:--|
|SC1|Pen-testing|N/A. Pen-testing in AWS is not allowed to be done at any certain moment for all their [services](https://aws.amazon.com/es/security/penetration-testing/).|CISO <br> Entity|
|SC2|Threat Model|N/A. AWS marketplace ofers some solutions from third party entities. ThreatModeler is a leading platform that automates the process to create a threat model, reducing the time-cost needed by up to 85%. |CCoE|
|SC3|RedTeam| eCISO is responsible for Red Teaming exercises. Read Teaming exercises should be performed periodically. Domain of Cyber ​​Tests, Identification and Management of Vulnerabilities.|CISO|
|SC4|Dynamic Application Security Testing (DAST)|N/A. [Amazon Inspector](https://docs.aws.amazon.com/es_es/inspector/latest/userguide/inspector_introduction.html) automatically assesses applications for exposure, vulnerabilities, and deviations from best practices. After performing an assessment, Amazon Inspector produces a detailed list of security findings prioritized by level of severity. These findings can be reviewed directly or as part of detailed assessment reports which are available via the Amazon Inspector console or API. |Entity|


# **Basic tf files description**

This section explain the structure and elements that represent the artifacts of product.

|Folder|Name|Description
|--|:-|--|
|Documentation|(documentation/User_pools.png)|Architecture diagram|
|Documentation|(documentation/Identity_pools.png)|Architecture diagram|
|Root|Readme.md|Product documentation file|
|Root|main.tf|Terraform file to use in pipeline to build and release a product|
|Root|outputs.tf|Terraform file to use in pipeline to check output|
|Root|variables.tf|Terraform file to define variables|
|Root|providers.tf|Terraform file to define required versions|


## Authors

Module written by CCoE

